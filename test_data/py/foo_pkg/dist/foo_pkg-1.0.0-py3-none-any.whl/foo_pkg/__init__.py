# A Python Package

def foo():
    return "foo"
