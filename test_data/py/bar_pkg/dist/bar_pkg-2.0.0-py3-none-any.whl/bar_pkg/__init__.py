# A Python Package

def bar():
    return "bar"
